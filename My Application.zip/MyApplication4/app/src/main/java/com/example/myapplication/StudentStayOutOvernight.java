package com.example.myapplication;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class StudentStayOutOvernight extends AppCompatActivity {

    private Button stayOutButton;
    private RecyclerView stayOutRecyclerView;
    private StayOutAdapter stayOutAdapter;
    private List<StayOutInfo> stayOutList;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_stayoutovernight);

        stayOutButton = findViewById(R.id.stayOutButton);
        stayOutRecyclerView = findViewById(R.id.stayOutRecyclerView);
        stayOutRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        stayOutList = new ArrayList<>();
        stayOutAdapter = new StayOutAdapter(stayOutList);
        stayOutRecyclerView.setAdapter(stayOutAdapter);

        stayOutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StayOutInfo newStayOut = new StayOutInfo("Request information for an overnight stay");
                stayOutList.add(newStayOut);
                stayOutAdapter.notifyItemInserted(stayOutList.size() - 1);
                showToast("Stay out requested");
            }
        });
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    // 외박 취소 메서드
    public void cancelStayOut(int position) {
        stayOutList.remove(position);
        stayOutAdapter.notifyItemRemoved(position);
        showToast("Stay out canceled");
    }

    private class StayOutAdapter extends RecyclerView.Adapter<StayOutAdapter.StayOutViewHolder> {
        private List<StayOutInfo> stayOutList;

        public StayOutAdapter(List<StayOutInfo> stayOutList) {
            this.stayOutList = stayOutList;
        }

        @Override
        public StayOutViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.stayout_item, parent, false);
            return new StayOutViewHolder(view);
        }

        @Override
        public void onBindViewHolder(StayOutViewHolder holder, int position) {
            StayOutInfo stayOutInfo = stayOutList.get(position);
            holder.textView.setText(stayOutInfo.getDescription());
        }

        @Override
        public int getItemCount() {
            return stayOutList.size();
        }

        public class StayOutViewHolder extends RecyclerView.ViewHolder {
            TextView textView;
            Button cancelButton;

            public StayOutViewHolder(View itemView) {
                super(itemView);
                textView = itemView.findViewById(R.id.textView);
                cancelButton = itemView.findViewById(R.id.cancelButton);
                cancelButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        cancelStayOut(getAdapterPosition());
                    }
                });
            }
        }
    }

    private class StayOutInfo {
        private String description;

        public StayOutInfo(String description) {
            this.description = description;
        }

        public String getDescription() {
            return description;
        }
    }
}