package com.example.myapplication;
import android.annotation.SuppressLint;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


public class ManagerRewardPunishmentPoint extends AppCompatActivity {


    private TextView penaltyTextView;
    private Button plusButton;
    private Button minusButton;
    private Button assignPenaltyButton;


    private int penaltyCount = 0;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manager_rewardpunishment_point);


        penaltyTextView = findViewById(R.id.penaltyTextView);
        plusButton = findViewById(R.id.plusButton);
        minusButton = findViewById(R.id.minusButton);
        assignPenaltyButton = findViewById(R.id.assignPenaltyButton);


        plusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (penaltyCount < 10) {
                    penaltyCount++;
                    updatePenaltyTextView();
                } else {
                    Toast.makeText(ManagerRewardPunishmentPoint.this, "Penalty points can only be registered up to 10 points.", Toast.LENGTH_SHORT).show();
                }
            }
        });


        minusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (penaltyCount > 0) {
                    penaltyCount--;
                    updatePenaltyTextView();
                } else {
                    Toast.makeText(ManagerRewardPunishmentPoint.this, "Penalty points cannot be set to less than zero points.", Toast.LENGTH_SHORT).show();
                }
            }
        });


        assignPenaltyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (penaltyCount > 0) {
                    // TODO: 관생에게 벌점을 부여하는 기능 구현
                    Toast.makeText(ManagerRewardPunishmentPoint.this, penaltyCount + "penalty points have been awarded.", Toast.LENGTH_SHORT).show();
                    penaltyCount = 0; // 부여 후 벌점 카운트 초기화
                    updatePenaltyTextView();
                } else {
                    Toast.makeText(ManagerRewardPunishmentPoint.this, "No penalty points to grant.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }


    private void updatePenaltyTextView() {
        penaltyTextView.setText(String.valueOf(penaltyCount));
    }
}
